import { UserProfile, AppState } from '../types/diabetes';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Heart, Home, Droplet, Pill, Utensils, BarChart3, Moon, Sun, User, Clock, Bell, Trophy, Settings } from 'lucide-react';
import GlucoseTab from './GlucoseTab';
import MedicineTab from './MedicineTab';
import FoodTab from './FoodTab';
import ReportsTab from './ReportsTab';
import ProfileTab from './ProfileTab';
import SettingsTab from './SettingsTab';
import { storage } from '../lib/storage';
import { useEffect, useState } from 'react';

interface DashboardScreenProps {
  userProfile: UserProfile;
  currentTab: AppState['currentTab'];
  darkMode: boolean;
  onTabChange: (tab: AppState['currentTab']) => void;
  onToggleDarkMode: () => void;
}

interface UpdatedDashboardProps extends DashboardScreenProps {
  onProfileUpdate: (profile: UserProfile) => void;
}

export default function DashboardScreen({ 
  userProfile, 
  currentTab, 
  darkMode, 
  onTabChange, 
  onToggleDarkMode 
}: DashboardScreenProps) {
  
  const handleProfileUpdate = (updatedProfile: UserProfile) => {
    // This will be handled by the parent component
    window.location.reload();
  };
  const [currentTime, setCurrentTime] = useState(new Date());
  const [stats, setStats] = useState({
    todayGlucose: 0,
    medicinesTaken: 0,
    totalMedicines: 0,
    averageGlucose: 0,
    normalReadings: 0,
    adherenceRate: 0
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    // Load stats
    const today = new Date().toISOString().split('T')[0];
    const glucoseReadings = storage.getGlucoseReadings(userProfile.id);
    const todayReadings = glucoseReadings.filter(r => r.timestamp.startsWith(today));
    const glucoseStats = storage.getGlucoseStats(userProfile.id, 7);
    const adherence = storage.getMedicineAdherence(userProfile.id, 7);
    const medicines = storage.getMedicines(userProfile.id);
    const takenToday = storage.getMedicineTakenRecords(userProfile.id, today);

    setStats({
      todayGlucose: todayReadings.length > 0 ? todayReadings[0].level : 0,
      medicinesTaken: takenToday.filter(t => t.taken).length,
      totalMedicines: medicines.length,
      averageGlucose: glucoseStats.average,
      normalReadings: Math.round((glucoseStats.normalCount / glucoseStats.totalCount) * 100) || 0,
      adherenceRate: adherence
    });

    return () => clearInterval(timer);
  }, [userProfile.id]);

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'সুপ্রভাত';
    if (hour < 18) return 'শুভ দুপুর';
    return 'শুভ সন্ধ্যা';
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('bn-BD', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const tabs = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: Home },
    { id: 'glucose', label: 'গ্লুকোজ', icon: Droplet },
    { id: 'medicine', label: 'ওষুধ', icon: Pill },
    { id: 'food', label: 'খাবার', icon: Utensils },
    { id: 'reports', label: 'রিপোর্ট', icon: BarChart3 },
    { id: 'profile', label: 'প্রোফাইল', icon: User },
    { id: 'settings', label: 'সেটিংস', icon: Trophy }
  ] as const;

  const renderTabContent = () => {
    switch (currentTab) {
      case 'glucose':
        return <GlucoseTab userProfile={userProfile} />;
      case 'medicine':
        return <MedicineTab userProfile={userProfile} />;
      case 'food':
        return <FoodTab userProfile={userProfile} />;
      case 'reports':
        return <ReportsTab userProfile={userProfile} />;
      case 'profile':
        return <ProfileTab userProfile={userProfile} onProfileUpdate={handleProfileUpdate} />;
      case 'settings':
        return <SettingsTab userProfile={userProfile} darkMode={darkMode} onToggleDarkMode={onToggleDarkMode} />;
      default:
        return (
          <div className="space-y-6">
            {/* Greeting */}
            <div className="bg-gradient-to-r from-primary to-teal-600 rounded-2xl p-6 text-white">
              <h2 className="text-2xl font-bold mb-2 bengali-font">
                {getGreeting()}, {userProfile.name}! 👋
              </h2>
              <p className="opacity-90 bengali-font">আজ আপনার স্বাস্থ্য কেমন লাগছে?</p>
              <div className="mt-4 text-sm opacity-80 flex items-center">
                <Clock className="mr-2" size={16} />
                <span className="bengali-font">
                  {currentTime.toLocaleTimeString('bn-BD', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })} - {getGreeting()}!
                </span>
              </div>
            </div>

            {/* Today's Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">আজকের গ্লুকোজ</p>
                      <p className="text-xl font-bold text-green-600">
                        {stats.todayGlucose > 0 ? `${stats.todayGlucose} mmol/L` : 'রিডিং নেই'}
                      </p>
                      <p className="text-xs text-green-600 bengali-font">
                        {stats.todayGlucose > 0 && stats.todayGlucose <= 10 ? 'স্বাভাবিক পর্যায়ে' : ''}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
                      <Droplet className="text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">ওষুধ সেবন</p>
                      <p className="text-xl font-bold text-primary">
                        {stats.medicinesTaken}/{stats.totalMedicines}
                      </p>
                      <p className="text-xs text-amber-600 bengali-font">
                        {stats.totalMedicines - stats.medicinesTaken > 0 ? 
                          `${stats.totalMedicines - stats.medicinesTaken}টি বাকি` : 
                          'সব সম্পন্ন'
                        }
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <Pill className="text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">BMI</p>
                      <p className="text-xl font-bold text-gray-800 dark:text-white">{userProfile.bmi}</p>
                      <p className="text-xs text-green-600 bengali-font">
                        {userProfile.bmi < 25 ? 'স্বাভাবিক' : userProfile.bmi < 30 ? 'অতিরিক্ত' : 'স্থূল'}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                      <User className="text-gray-600 dark:text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center bengali-font">
                <Trophy className="mr-2 text-amber-500" />
                দ্রুত অ্যাকশন
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button
                  variant="outline"
                  className="quick-action-btn h-auto"
                  onClick={() => onTabChange('glucose')}
                >
                  <div className="flex flex-col items-center space-y-2">
                    <Droplet className="text-2xl text-primary" size={32} />
                    <span className="bengali-font">গ্লুকোজ যোগ করুন</span>
                  </div>
                </Button>
                
                <Button
                  variant="outline"
                  className="quick-action-btn h-auto"
                  onClick={() => onTabChange('medicine')}
                >
                  <div className="flex flex-col items-center space-y-2">
                    <Pill className="text-2xl text-green-600" size={32} />
                    <span className="bengali-font">ওষুধ নিয়েছি</span>
                  </div>
                </Button>
                
                <Button
                  variant="outline"
                  className="quick-action-btn h-auto"
                  onClick={() => onTabChange('food')}
                >
                  <div className="flex flex-col items-center space-y-2">
                    <Utensils className="text-2xl text-amber-600" size={32} />
                    <span className="bengali-font">খাবার যোগ করুন</span>
                  </div>
                </Button>
                
                <Button
                  variant="outline"
                  className="quick-action-btn h-auto"
                  onClick={() => onTabChange('reports')}
                >
                  <div className="flex flex-col items-center space-y-2">
                    <BarChart3 className="text-2xl text-purple-600" size={32} />
                    <span className="bengali-font">রিপোর্ট ডাউনলোড</span>
                  </div>
                </Button>
              </div>
            </div>

            {/* Notifications */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center bengali-font">
                  <Bell className="mr-2 text-primary" />
                  বিজ্ঞপ্তি
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats.totalMedicines - stats.medicinesTaken > 0 && (
                    <div className="flex items-start space-x-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                      <Clock className="text-amber-600 mt-1" size={16} />
                      <div>
                        <p className="font-medium text-gray-800 dark:text-white bengali-font">ওষুধের সময়</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                          আজ {stats.totalMedicines - stats.medicinesTaken}টি ওষুধ খাওয়া বাকি আছে
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {stats.normalReadings >= 70 && (
                    <div className="flex items-start space-x-3 p-3 bg-primary/10 rounded-lg">
                      <Heart className="text-primary mt-1" size={16} />
                      <div>
                        <p className="font-medium text-gray-800 dark:text-white bengali-font">দুর্দান্ত অগ্রগতি!</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                          গত সপ্তাহে আপনার {stats.normalReadings}% গ্লুকোজ স্বাভাবিক ছিল
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {stats.adherenceRate >= 80 && (
                    <div className="flex items-start space-x-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <Trophy className="text-green-600 mt-1" size={16} />
                      <div>
                        <p className="font-medium text-gray-800 dark:text-white bengali-font">চমৎকার অনুসরণ!</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                          আপনি {stats.adherenceRate}% ওষুধ সময়মতো খেয়েছেন
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center mr-3">
                <Heart className="text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-800 dark:text-white bengali-font">ডায়াবেটিস সাথী</h1>
                <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                  {formatDate(currentTime)}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {/* Dark Mode Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleDarkMode}
                className="p-2 rounded-lg"
              >
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              {/* Profile */}
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <User className="text-white text-sm" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40">
        <div className="container mx-auto px-4">
          <div className="flex space-x-1 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <Button
                  key={tab.id}
                  variant="ghost"
                  className={`nav-tab px-4 py-3 text-sm font-medium rounded-t-lg whitespace-nowrap bengali-font ${
                    currentTab === tab.id ? 'active' : ''
                  }`}
                  onClick={() => onTabChange(tab.id)}
                >
                  <Icon className="mr-2" size={16} />
                  {tab.label}
                </Button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Tab Content */}
      <main className="container mx-auto px-4 py-6">
        {renderTabContent()}
      </main>
    </div>
  );
}
