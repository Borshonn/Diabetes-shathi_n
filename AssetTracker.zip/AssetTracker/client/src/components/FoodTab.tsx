import { useState, useEffect } from 'react';
import { UserProfile, FoodEntry, BANGLADESH_FOODS } from '../types/diabetes';
import { storage } from '../lib/storage';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { PlusCircle, List, Coffee, Sun, Sunset, Moon, Save } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

interface FoodTabProps {
  userProfile: UserProfile;
}

export default function FoodTab({ userProfile }: FoodTabProps) {
  const { toast } = useToast();
  const [foodEntries, setFoodEntries] = useState<FoodEntry[]>([]);
  const [todayEntries, setTodayEntries] = useState<FoodEntry[]>([]);
  const [formData, setFormData] = useState({
    mealType: 'breakfast',
    selectedFood: ''
  });
  const [currentMealFoods, setCurrentMealFoods] = useState<string[]>([]);

  useEffect(() => {
    loadFoodEntries();
  }, [userProfile.id]);

  const loadFoodEntries = () => {
    const today = new Date().toISOString().split('T')[0];
    const allEntries = storage.getFoodEntries(userProfile.id);
    const todayEntries = storage.getFoodEntries(userProfile.id, today);
    
    setFoodEntries(allEntries);
    setTodayEntries(todayEntries);
  };

  const handleAddFood = () => {
    if (!formData.selectedFood) {
      toast({
        title: "ত্রুটি",
        description: "অনুগ্রহ করে একটি খাবার নির্বাচন করুন",
        variant: "destructive"
      });
      return;
    }

    setCurrentMealFoods(prev => [...prev, formData.selectedFood]);
    setFormData(prev => ({ ...prev, selectedFood: '' }));
  };

  const handleRemoveFood = (index: number) => {
    setCurrentMealFoods(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (currentMealFoods.length === 0) {
      toast({
        title: "ত্রুটি",
        description: "অনুগ্রহ করে অন্তত একটি খাবার যোগ করুন",
        variant: "destructive"
      });
      return;
    }

    const entry: FoodEntry = {
      id: Date.now().toString(),
      mealType: formData.mealType as 'breakfast' | 'lunch' | 'dinner' | 'snacks',
      foods: currentMealFoods,
      timestamp: new Date().toISOString(),
      userId: userProfile.id
    };

    storage.saveFoodEntry(entry);
    loadFoodEntries();
    
    setCurrentMealFoods([]);
    setFormData({
      mealType: 'breakfast',
      selectedFood: ''
    });

    toast({
      title: "সফল!",
      description: "✅ খাবার সংরক্ষিত হয়েছে!",
    });
  };

  const getMealTypeText = (mealType: string) => {
    switch (mealType) {
      case 'breakfast': return 'নাস্তা';
      case 'lunch': return 'দুপুরের খাবার';
      case 'dinner': return 'রাতের খাবার';
      case 'snacks': return 'জলখাবার';
      default: return mealType;
    }
  };

  const getMealIcon = (mealType: string) => {
    switch (mealType) {
      case 'breakfast': return <Sun className="w-5 h-5 text-yellow-500" />;
      case 'lunch': return <Sun className="w-5 h-5 text-orange-500" />;
      case 'dinner': return <Sunset className="w-5 h-5 text-purple-500" />;
      case 'snacks': return <Coffee className="w-5 h-5 text-brown-500" />;
      default: return <Sun className="w-5 h-5" />;
    }
  };

  const getCurrentFoodOptions = () => {
    return BANGLADESH_FOODS[formData.mealType as keyof typeof BANGLADESH_FOODS] || [];
  };

  const groupEntriesByMeal = (entries: FoodEntry[]) => {
    return entries.reduce((acc, entry) => {
      if (!acc[entry.mealType]) {
        acc[entry.mealType] = [];
      }
      acc[entry.mealType].push(entry);
      return acc;
    }, {} as Record<string, FoodEntry[]>);
  };

  return (
    <div className="space-y-6">
      {/* Add Food Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <PlusCircle className="mr-2 text-primary" />
            খাবার যোগ করুন
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="mealType" className="bengali-font">খাবারের ধরন</Label>
                <Select 
                  value={formData.mealType} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, mealType: value }))}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="breakfast">নাস্তা</SelectItem>
                    <SelectItem value="lunch">দুপুরের খাবার</SelectItem>
                    <SelectItem value="dinner">রাতের খাবার</SelectItem>
                    <SelectItem value="snacks">জলখাবার</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="food" className="bengali-font">খাবার</Label>
                <Select 
                  value={formData.selectedFood} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, selectedFood: value }))}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="নির্বাচন করুন" />
                  </SelectTrigger>
                  <SelectContent>
                    {getCurrentFoodOptions().map((food) => (
                      <SelectItem key={food} value={food}>{food}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-end">
                <Button
                  type="button"
                  onClick={handleAddFood}
                  variant="outline"
                  className="w-full bengali-font"
                >
                  <PlusCircle className="mr-2" size={16} />
                  যোগ করুন
                </Button>
              </div>
            </div>

            {/* Current Meal Foods */}
            {currentMealFoods.length > 0 && (
              <div>
                <Label className="bengali-font">বর্তমান খাবার:</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {currentMealFoods.map((food, index) => (
                    <Badge
                      key={index}
                      variant="secondary"
                      className="cursor-pointer"
                      onClick={() => handleRemoveFood(index)}
                    >
                      {food} ✕
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {currentMealFoods.length > 0 && (
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 bengali-font">
                <Save className="mr-2" size={16} />
                সংরক্ষণ করুন
              </Button>
            )}
          </form>
        </CardContent>
      </Card>

      {/* Today's Food Log */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <List className="mr-2 text-primary" />
            আজকের খাবার
          </CardTitle>
        </CardHeader>
        <CardContent>
          {todayEntries.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400 bengali-font">
                আজ এখনো কোনো খাবার লগ করা হয়নি। উপরের ফর্ম ব্যবহার করে খাবার যোগ করুন।
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(groupEntriesByMeal(todayEntries)).map(([mealType, entries]) => (
                <div key={mealType} className="border-l-4 border-primary pl-4">
                  <div className="flex items-center space-x-2 mb-2">
                    {getMealIcon(mealType)}
                    <h4 className="font-medium text-gray-800 dark:text-white bengali-font">
                      {getMealTypeText(mealType)}
                    </h4>
                    <span className="text-sm text-gray-500">
                      {entries.length > 1 ? `(${entries.length} বার)` : ''}
                    </span>
                  </div>
                  
                  {entries.map((entry) => (
                    <div key={entry.id} className="mb-2">
                      <div className="flex flex-wrap gap-2">
                        {entry.foods.map((food, index) => (
                          <Badge key={index} variant="outline">
                            {food}
                          </Badge>
                        ))}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(entry.timestamp).toLocaleTimeString('bn-BD', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Food Statistics */}
      {foodEntries.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="bengali-font">খাবারের পরিসংখ্যান (গত ৭ দিন)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(BANGLADESH_FOODS).map(([mealType, foods]) => {
                const count = foodEntries
                  .filter(entry => entry.mealType === mealType)
                  .filter(entry => {
                    const entryDate = new Date(entry.timestamp);
                    const weekAgo = new Date();
                    weekAgo.setDate(weekAgo.getDate() - 7);
                    return entryDate >= weekAgo;
                  }).length;
                
                return (
                  <div key={mealType} className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex justify-center mb-2">
                      {getMealIcon(mealType)}
                    </div>
                    <p className="text-sm font-medium text-gray-800 dark:text-white bengali-font">
                      {getMealTypeText(mealType)}
                    </p>
                    <p className="text-2xl font-bold text-primary">{count}</p>
                    <p className="text-xs text-gray-500 bengali-font">বার লগ করা</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
