import { useState } from 'react';
import { UserProfile } from '../types/diabetes';
import { storage } from '../lib/storage';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { User, Edit3, Save, Calculator } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

interface ProfileTabProps {
  userProfile: UserProfile;
  onProfileUpdate: (profile: UserProfile) => void;
}

export default function ProfileTab({ userProfile, onProfileUpdate }: ProfileTabProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: userProfile.name,
    age: userProfile.age.toString(),
    gender: userProfile.gender,
    diabetesType: userProfile.diabetesType,
    weight: userProfile.weight.toString(),
    height: userProfile.height.toString(),
    phone: userProfile.phone || ''
  });

  const calculateBMI = (weight: number, height: number) => {
    const heightInM = height / 100;
    return Math.round((weight / (heightInM * heightInM)) * 10) / 10;
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { text: 'কম ওজন', color: 'text-blue-600' };
    if (bmi < 25) return { text: 'স্বাভাবিক', color: 'text-green-600' };
    if (bmi < 30) return { text: 'অতিরিক্ত ওজন', color: 'text-yellow-600' };
    return { text: 'স্থূলতা', color: 'text-red-600' };
  };

  const handleSave = () => {
    if (!formData.name || !formData.age || !formData.weight || !formData.height) {
      toast({
        title: "ত্রুটি",
        description: "অনুগ্রহ করে সব প্রয়োজনীয় তথ্য পূরণ করুন",
        variant: "destructive"
      });
      return;
    }

    const weight = parseFloat(formData.weight);
    const height = parseFloat(formData.height);
    const bmi = calculateBMI(weight, height);

    const updatedProfile: UserProfile = {
      ...userProfile,
      name: formData.name,
      age: parseInt(formData.age),
      gender: formData.gender as 'male' | 'female' | 'other',
      diabetesType: formData.diabetesType as 'type1' | 'type2' | 'unknown',
      weight,
      height,
      phone: formData.phone,
      bmi
    };

    storage.saveUserProfile(updatedProfile);
    onProfileUpdate(updatedProfile);
    setIsEditing(false);

    toast({
      title: "সফল!",
      description: "প্রোফাইল আপডেট করা হয়েছে",
    });
  };

  const handleCancel = () => {
    setFormData({
      name: userProfile.name,
      age: userProfile.age.toString(),
      gender: userProfile.gender,
      diabetesType: userProfile.diabetesType,
      weight: userProfile.weight.toString(),
      height: userProfile.height.toString(),
      phone: userProfile.phone || ''
    });
    setIsEditing(false);
  };

  const currentBMI = calculateBMI(parseFloat(formData.weight) || userProfile.weight, parseFloat(formData.height) || userProfile.height);
  const bmiCategory = getBMICategory(currentBMI);

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between bengali-font">
            <div className="flex items-center">
              <User className="mr-2 text-primary" />
              আমার প্রোফাইল
            </div>
            {!isEditing && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setIsEditing(true)}
                className="bengali-font"
              >
                <Edit3 className="mr-2" size={16} />
                সম্পাদনা
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="name" className="bengali-font">নাম</Label>
                {isEditing ? (
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="mt-2"
                  />
                ) : (
                  <p className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded">{userProfile.name}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age" className="bengali-font">বয়স</Label>
                  {isEditing ? (
                    <Input
                      id="age"
                      type="number"
                      value={formData.age}
                      onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                      className="mt-2"
                    />
                  ) : (
                    <p className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded">{userProfile.age} বছর</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="gender" className="bengali-font">লিঙ্গ</Label>
                  {isEditing ? (
                    <Select value={formData.gender} onValueChange={(value) => setFormData(prev => ({ ...prev, gender: value }))}>
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">পুরুষ</SelectItem>
                        <SelectItem value="female">নারী</SelectItem>
                        <SelectItem value="other">অন্যান্য</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <p className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded">
                      {userProfile.gender === 'male' ? 'পুরুষ' : userProfile.gender === 'female' ? 'নারী' : 'অন্যান্য'}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="diabetesType" className="bengali-font">ডায়াবেটিসের ধরন</Label>
                {isEditing ? (
                  <Select value={formData.diabetesType} onValueChange={(value) => setFormData(prev => ({ ...prev, diabetesType: value }))}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="type1">টাইপ ১</SelectItem>
                      <SelectItem value="type2">টাইপ ২</SelectItem>
                      <SelectItem value="unknown">জানা নেই</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <p className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded">
                    {userProfile.diabetesType === 'type1' ? 'টাইপ ১' : userProfile.diabetesType === 'type2' ? 'টাইপ ২' : 'জানা নেই'}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="phone" className="bengali-font">মোবাইল নম্বর</Label>
                {isEditing ? (
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    className="mt-2"
                    placeholder="+880 1234567890"
                  />
                ) : (
                  <p className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded">
                    {userProfile.phone || 'যোগ করা হয়নি'}
                  </p>
                )}
              </div>
            </div>

            {/* Physical Information */}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="weight" className="bengali-font">ওজন (কেজি)</Label>
                  {isEditing ? (
                    <Input
                      id="weight"
                      type="number"
                      step="0.1"
                      value={formData.weight}
                      onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                      className="mt-2"
                    />
                  ) : (
                    <p className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded">{userProfile.weight} কেজি</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="height" className="bengali-font">উচ্চতা (সেমি)</Label>
                  {isEditing ? (
                    <Input
                      id="height"
                      type="number"
                      value={formData.height}
                      onChange={(e) => setFormData(prev => ({ ...prev, height: e.target.value }))}
                      className="mt-2"
                    />
                  ) : (
                    <p className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded">{userProfile.height} সেমি</p>
                  )}
                </div>
              </div>

              {/* BMI Calculator */}
              <Card className="bg-gradient-to-r from-primary/10 to-teal-50 dark:from-primary/20 dark:to-gray-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <Calculator className="text-primary" size={20} />
                        <h4 className="font-semibold text-gray-800 dark:text-white bengali-font">BMI ক্যালকুলেটর</h4>
                      </div>
                      <p className="text-2xl font-bold text-primary mt-2">
                        {currentBMI}
                      </p>
                      <p className={`text-sm font-medium ${bmiCategory.color} bengali-font`}>
                        {bmiCategory.text}
                      </p>
                    </div>
                    <div className="text-right text-sm text-gray-600 dark:text-gray-400">
                      <p className="bengali-font">স্বাভাবিক পরিসর:</p>
                      <p className="font-medium">18.5 - 24.9</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="text-xs text-gray-500 dark:text-gray-400 bengali-font">
                প্রোফাইল তৈরি: {new Date(userProfile.createdAt).toLocaleDateString('bn-BD')}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          {isEditing && (
            <div className="flex space-x-4 mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button onClick={handleSave} className="bg-primary hover:bg-primary/90 bengali-font">
                <Save className="mr-2" size={16} />
                সংরক্ষণ করুন
              </Button>
              <Button variant="outline" onClick={handleCancel} className="bengali-font">
                বাতিল
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}