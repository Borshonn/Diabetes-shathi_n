import { useState, useEffect } from 'react';
import { UserProfile, GlucoseReading } from '../types/diabetes';
import { storage } from '../lib/storage';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { PlusCircle, TrendingUp, History, Edit, Trash2, Save } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

interface GlucoseTabProps {
  userProfile: UserProfile;
}

export default function GlucoseTab({ userProfile }: GlucoseTabProps) {
  const { toast } = useToast();
  const [readings, setReadings] = useState<GlucoseReading[]>([]);
  const [formData, setFormData] = useState({
    level: '',
    type: 'fasting',
    time: new Date().toTimeString().slice(0, 5)
  });

  useEffect(() => {
    loadReadings();
  }, [userProfile.id]);

  const loadReadings = () => {
    const userReadings = storage.getGlucoseReadings(userProfile.id);
    setReadings(userReadings);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.level || !formData.type || !formData.time) {
      toast({
        title: "ত্রুটি",
        description: "অনুগ্রহ করে সব তথ্য পূরণ করুন",
        variant: "destructive"
      });
      return;
    }

    const reading: GlucoseReading = {
      id: Date.now().toString(),
      level: parseFloat(formData.level),
      type: formData.type as 'fasting' | 'post-meal' | 'random',
      time: formData.time,
      timestamp: new Date().toISOString(),
      userId: userProfile.id
    };

    storage.saveGlucoseReading(reading);
    loadReadings();
    
    setFormData({
      level: '',
      type: 'fasting',
      time: new Date().toTimeString().slice(0, 5)
    });

    toast({
      title: "সফল!",
      description: "✅ গ্লুকোজ রিডিং সংরক্ষিত হয়েছে!",
    });
  };

  const handleDelete = (id: string) => {
    storage.deleteGlucoseReading(id);
    loadReadings();
    toast({
      title: "মুছে ফেলা হয়েছে",
      description: "গ্লুকোজ রিডিং সফলভাবে মুছে ফেলা হয়েছে",
    });
  };

  const getGlucoseStatus = (level: number) => {
    if (level <= 7) return { status: 'স্বাভাবিক', class: 'glucose-normal' };
    if (level <= 10) return { status: 'সীমান্তরেখা', class: 'glucose-high' };
    return { status: 'উচ্চ', class: 'glucose-critical' };
  };

  const getReadingTypeText = (type: string) => {
    switch (type) {
      case 'fasting': return 'খালি পেটে';
      case 'post-meal': return 'খাবারের পর';
      case 'random': return 'যেকোনো সময়';
      default: return type;
    }
  };

  const getChartData = () => {
    return readings.slice(0, 7).reverse().map(reading => ({
      date: new Date(reading.timestamp).toLocaleDateString('bn-BD', { 
        weekday: 'short',
        day: 'numeric'
      }),
      level: reading.level,
      type: reading.type
    }));
  };

  return (
    <div className="space-y-6">
      {/* Add Glucose Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <PlusCircle className="mr-2 text-primary" />
            নতুন গ্লুকোজ রিডিং
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="level" className="bengali-font">মাত্রা (mmol/L)</Label>
              <Input
                id="level"
                type="number"
                step="0.1"
                placeholder="৮.২"
                value={formData.level}
                onChange={(e) => setFormData(prev => ({ ...prev, level: e.target.value }))}
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="type" className="bengali-font">ধরন</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fasting">খালি পেটে</SelectItem>
                  <SelectItem value="post-meal">খাবারের পর</SelectItem>
                  <SelectItem value="random">যেকোনো সময়</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="time" className="bengali-font">সময়</Label>
              <Input
                id="time"
                type="time"
                value={formData.time}
                onChange={(e) => setFormData(prev => ({ ...prev, time: e.target.value }))}
                className="mt-2"
              />
            </div>
            <div className="flex items-end">
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 bengali-font">
                <Save className="mr-2" size={16} />
                সংরক্ষণ করুন
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Glucose Chart */}
      {readings.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center bengali-font">
              <TrendingUp className="mr-2 text-primary" />
              গ্লুকোজ ট্রেন্ড (গত ৭ দিন)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={getChartData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => [`${value} mmol/L`, 'গ্লুকোজ']}
                    labelStyle={{ color: '#000' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="level" 
                    stroke="#14B8A6" 
                    strokeWidth={3}
                    dot={{ fill: '#14B8A6', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Readings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <History className="mr-2 text-primary" />
            সাম্প্রতিক রিডিং
          </CardTitle>
        </CardHeader>
        <CardContent>
          {readings.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400 bengali-font">
                এখনো কোনো গ্লুকোজ রিডিং নেই। উপরের ফর্ম ব্যবহার করে প্রথম রিডিং যোগ করুন।
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {readings.slice(0, 10).map((reading) => {
                const { status, class: statusClass } = getGlucoseStatus(reading.level);
                return (
                  <div key={reading.id} className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${statusClass}`}></div>
                      <div>
                        <p className="font-medium text-gray-800 dark:text-white">
                          {reading.level} mmol/L
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                          {getReadingTypeText(reading.type)} • {reading.time} • {status}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-500">
                          {new Date(reading.timestamp).toLocaleDateString('bn-BD')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(reading.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
