import { useState } from 'react';
import { UserProfile } from '../types/diabetes';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { UserPlus, ArrowRight } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

interface OnboardingScreenProps {
  onComplete: (profile: UserProfile) => void;
}

export default function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    diabetesType: '',
    weight: '',
    height: '',
    phone: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.age || !formData.gender || !formData.diabetesType || !formData.weight || !formData.height) {
      toast({
        title: "ত্রুটি",
        description: "অনুগ্রহ করে সব প্রয়োজনীয় তথ্য পূরণ করুন",
        variant: "destructive"
      });
      return;
    }

    const heightInM = parseFloat(formData.height) / 100;
    const bmi = parseFloat(formData.weight) / (heightInM * heightInM);

    const profile: UserProfile = {
      id: Date.now().toString(),
      name: formData.name,
      age: parseInt(formData.age),
      gender: formData.gender as 'male' | 'female' | 'other',
      diabetesType: formData.diabetesType as 'type1' | 'type2' | 'unknown',
      weight: parseFloat(formData.weight),
      height: parseFloat(formData.height),
      phone: formData.phone,
      bmi: Math.round(bmi * 10) / 10,
      createdAt: new Date().toISOString()
    };

    toast({
      title: "স্বাগতম!",
      description: "আপনার প্রোফাইল সফলভাবে তৈরি হয়েছে",
    });

    onComplete(profile);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-teal-100 dark:from-primary/20 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <UserPlus className="text-white text-xl" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2 bengali-font">স্বাগতম!</h1>
          <p className="text-gray-600 dark:text-gray-300 bengali-font">আপনার প্রোফাইল তৈরি করুন</p>
        </div>

        {/* Onboarding Form */}
        <div className="max-w-md mx-auto">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="bengali-font">ব্যক্তিগত তথ্য</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name */}
                <div>
                  <Label htmlFor="name" className="bengali-font">নাম *</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="আপনার নাম লিখুন"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className="mt-2"
                    required
                  />
                </div>

                {/* Age & Gender */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="age" className="bengali-font">বয়স *</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="25"
                      value={formData.age}
                      onChange={(e) => handleInputChange('age', e.target.value)}
                      className="mt-2"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="gender" className="bengali-font">লিঙ্গ *</Label>
                    <Select value={formData.gender} onValueChange={(value) => handleInputChange('gender', value)}>
                      <SelectTrigger className="mt-2">
                        <SelectValue placeholder="নির্বাচন করুন" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">পুরুষ</SelectItem>
                        <SelectItem value="female">নারী</SelectItem>
                        <SelectItem value="other">অন্যান্য</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Diabetes Type */}
                <div>
                  <Label htmlFor="diabetesType" className="bengali-font">ডায়াবেটিসের ধরন *</Label>
                  <Select value={formData.diabetesType} onValueChange={(value) => handleInputChange('diabetesType', value)}>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="নির্বাচন করুন" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="type1">টাইপ ১</SelectItem>
                      <SelectItem value="type2">টাইপ ২</SelectItem>
                      <SelectItem value="unknown">জানা নেই</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Weight & Height */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="weight" className="bengali-font">ওজন (কেজি) *</Label>
                    <Input
                      id="weight"
                      type="number"
                      step="0.1"
                      placeholder="65"
                      value={formData.weight}
                      onChange={(e) => handleInputChange('weight', e.target.value)}
                      className="mt-2"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="height" className="bengali-font">উচ্চতা (সেমি) *</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="165"
                      value={formData.height}
                      onChange={(e) => handleInputChange('height', e.target.value)}
                      className="mt-2"
                      required
                    />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <Label htmlFor="phone" className="bengali-font">মোবাইল নম্বর (ঐচ্ছিক)</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+880 1234567890"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="mt-2"
                  />
                </div>

                {/* Submit Button */}
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-3 bengali-font">
                  <ArrowRight className="mr-2" size={20} />
                  শুরু করুন
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
