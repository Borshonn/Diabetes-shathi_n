import { Heart } from 'lucide-react';

export default function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-white dark:bg-gray-900 flex items-center justify-center z-50">
      <div className="text-center">
        <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mb-4 mx-auto">
          <Heart className="text-white text-2xl animate-pulse" size={32} />
        </div>
        <h1 className="text-2xl font-bold text-primary mb-2 bengali-font">ডায়াবেটিস সাথী</h1>
        <p className="text-gray-600 dark:text-gray-400 bengali-font">স্বাস্থ্য ব্যবস্থাপনা লোড হচ্ছে...</p>
        <div className="mt-4">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    </div>
  );
}
