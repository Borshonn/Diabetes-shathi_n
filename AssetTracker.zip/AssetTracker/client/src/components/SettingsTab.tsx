import { useState } from 'react';
import { UserProfile } from '../types/diabetes';
import { storage } from '../lib/storage';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Settings, Bell, Download, Trash2, RefreshCw, Shield, Moon, Sun, Globe, Database } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

interface SettingsTabProps {
  userProfile: UserProfile;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function SettingsTab({ userProfile, darkMode, onToggleDarkMode }: SettingsTabProps) {
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    notifications: true,
    medicineReminders: true,
    glucoseReminders: true,
    dataBackup: true,
    autoSync: false,
    language: 'bn',
    glucoseUnit: 'mmol/L',
    reminderSound: true,
    vibration: true,
    dataRetention: '365' // days
  });

  const handleSettingChange = (key: string, value: boolean | string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    localStorage.setItem('appSettings', JSON.stringify({ ...settings, [key]: value }));
    
    toast({
      title: "সেটিংস আপডেট",
      description: "সেটিংস সফলভাবে সংরক্ষিত হয়েছে",
    });
  };

  const handleExportData = () => {
    try {
      const glucoseReadings = storage.getGlucoseReadings(userProfile.id);
      const medicines = storage.getMedicines(userProfile.id);
      const foodEntries = storage.getFoodEntries(userProfile.id);
      
      const exportData = {
        profile: userProfile,
        glucoseReadings,
        medicines,
        foodEntries,
        exportDate: new Date().toISOString(),
        version: '1.0'
      };

      const dataStr = JSON.stringify(exportData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `diabetes_data_${userProfile.name}_${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      
      URL.revokeObjectURL(url);
      
      toast({
        title: "ডেটা এক্সপোর্ট সফল",
        description: "আপনার সম্পূর্ণ ডেটা ডাউনলোড হয়েছে",
      });
    } catch (error) {
      toast({
        title: "ত্রুটি",
        description: "ডেটা এক্সপোর্ট করতে সমস্যা হয়েছে",
        variant: "destructive"
      });
    }
  };

  const handleClearData = () => {
    if (window.confirm('আপনি কি নিশ্চিত যে সব ডেটা মুছে ফেলতে চান? এই কাজটি আর ফিরিয়ে আনা যাবে না।')) {
      localStorage.clear();
      toast({
        title: "ডেটা মুছে ফেলা হয়েছে",
        description: "সব তথ্য সফলভাবে মুছে ফেলা হয়েছে",
        variant: "destructive"
      });
      // Reload page after clearing data
      setTimeout(() => window.location.reload(), 2000);
    }
  };

  const handleResetSettings = () => {
    const defaultSettings = {
      notifications: true,
      medicineReminders: true,
      glucoseReminders: true,
      dataBackup: true,
      autoSync: false,
      language: 'bn',
      glucoseUnit: 'mmol/L',
      reminderSound: true,
      vibration: true,
      dataRetention: '365'
    };
    
    setSettings(defaultSettings);
    localStorage.setItem('appSettings', JSON.stringify(defaultSettings));
    
    toast({
      title: "সেটিংস রিসেট",
      description: "সব সেটিংস ডিফল্ট অবস্থায় ফিরিয়ে দেওয়া হয়েছে",
    });
  };

  return (
    <div className="space-y-6">
      {/* Settings Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <Settings className="mr-2 text-primary" />
            অ্যাপ সেটিংস
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Appearance Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-lg bengali-font">
            {darkMode ? <Moon className="mr-2" /> : <Sun className="mr-2" />}
            চেহারা ও থিম
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">ডার্ক মোড</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                রাতের জন্য অন্ধকার থিম ব্যবহার করুন
              </p>
            </div>
            <Switch
              checked={darkMode}
              onCheckedChange={onToggleDarkMode}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">ভাষা</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                অ্যাপের ভাষা নির্বাচন করুন
              </p>
            </div>
            <Select 
              value={settings.language} 
              onValueChange={(value) => handleSettingChange('language', value)}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="bn">বাংলা</SelectItem>
                <SelectItem value="en">English</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-lg bengali-font">
            <Bell className="mr-2" />
            বিজ্ঞপ্তি সেটিংস
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">পুশ নোটিফিকেশন</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                সাধারণ বিজ্ঞপ্তি চালু/বন্ধ করুন
              </p>
            </div>
            <Switch
              checked={settings.notifications}
              onCheckedChange={(checked) => handleSettingChange('notifications', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">ওষুধের রিমাইন্ডার</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                ওষুধ খাওয়ার সময় মনে করিয়ে দিন
              </p>
            </div>
            <Switch
              checked={settings.medicineReminders}
              onCheckedChange={(checked) => handleSettingChange('medicineReminders', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">গ্লুকোজ টেস্ট রিমাইন্ডার</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                গ্লুকোজ পরীক্ষার সময় মনে করিয়ে দিন
              </p>
            </div>
            <Switch
              checked={settings.glucoseReminders}
              onCheckedChange={(checked) => handleSettingChange('glucoseReminders', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">সাউন্ড</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                রিমাইন্ডারে শব্দ চালু করুন
              </p>
            </div>
            <Switch
              checked={settings.reminderSound}
              onCheckedChange={(checked) => handleSettingChange('reminderSound', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">ভাইব্রেশন</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                রিমাইন্ডারে কম্পন চালু করুন
              </p>
            </div>
            <Switch
              checked={settings.vibration}
              onCheckedChange={(checked) => handleSettingChange('vibration', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Data Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-lg bengali-font">
            <Database className="mr-2" />
            ডেটা ব্যবস্থাপনা
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">গ্লুকোজ একক</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                গ্লুকোজ পরিমাপের একক নির্বাচন করুন
              </p>
            </div>
            <Select 
              value={settings.glucoseUnit} 
              onValueChange={(value) => handleSettingChange('glucoseUnit', value)}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mmol/L">mmol/L</SelectItem>
                <SelectItem value="mg/dL">mg/dL</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">ডেটা ব্যাকআপ</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                স্বয়ংক্রিয় ডেটা ব্যাকআপ চালু করুন
              </p>
            </div>
            <Switch
              checked={settings.dataBackup}
              onCheckedChange={(checked) => handleSettingChange('dataBackup', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="bengali-font">ডেটা সংরক্ষণ সময়কাল</Label>
              <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                কত দিন ডেটা রাখবেন
              </p>
            </div>
            <Select 
              value={settings.dataRetention} 
              onValueChange={(value) => handleSettingChange('dataRetention', value)}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="90">৩ মাস</SelectItem>
                <SelectItem value="180">৬ মাস</SelectItem>
                <SelectItem value="365">১ বছর</SelectItem>
                <SelectItem value="730">২ বছর</SelectItem>
                <SelectItem value="-1">সব সময়</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Data Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-lg bengali-font">
            <Shield className="mr-2" />
            ডেটা কার্যক্রম
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button 
              onClick={handleExportData}
              variant="outline" 
              className="w-full bengali-font"
            >
              <Download className="mr-2" size={16} />
              ডেটা এক্সপোর্ট করুন
            </Button>
            
            <Button 
              onClick={handleResetSettings}
              variant="outline" 
              className="w-full bengali-font"
            >
              <RefreshCw className="mr-2" size={16} />
              সেটিংস রিসেট
            </Button>
          </div>
          
          <Button 
            onClick={handleClearData}
            variant="destructive" 
            className="w-full bengali-font"
          >
            <Trash2 className="mr-2" size={16} />
            সব ডেটা মুছে ফেলুন
          </Button>
          
          <p className="text-xs text-gray-500 dark:text-gray-400 text-center bengali-font">
            সাবধান: ডেটা মুছে ফেলার পর আর ফিরিয়ে আনা যাবে না
          </p>
        </CardContent>
      </Card>

      {/* App Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-lg bengali-font">
            <Globe className="mr-2" />
            অ্যাপ তথ্য
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400 bengali-font">অ্যাপের নাম:</span>
              <span className="font-medium bengali-font">ডায়াবেটিস সাথী</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400 bengali-font">সংস্করণ:</span>
              <span className="font-medium">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400 bengali-font">তৈরি করেছেন:</span>
              <span className="font-medium">GlucoShathi KUET Team</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400 bengali-font">সর্বশেষ আপডেট:</span>
              <span className="font-medium">{new Date().toLocaleDateString('bn-BD')}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}