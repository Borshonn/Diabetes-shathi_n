import { useState, useEffect } from 'react';
import { UserProfile, Medicine, MedicineTaken } from '../types/diabetes';
import { storage } from '../lib/storage';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { PlusCircle, CalendarDays, PieChart, Save, Trash2, Clock, CheckCircle } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

interface MedicineTabProps {
  userProfile: UserProfile;
}

export default function MedicineTab({ userProfile }: MedicineTabProps) {
  const { toast } = useToast();
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [todaySchedule, setTodaySchedule] = useState<Array<{
    medicine: Medicine;
    times: string[];
    taken: boolean[];
  }>>([]);
  const [adherenceRate, setAdherenceRate] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    dosage: '',
    frequency: 'daily'
  });

  useEffect(() => {
    loadMedicines();
    loadTodaySchedule();
    loadAdherence();
  }, [userProfile.id]);

  const loadMedicines = () => {
    const userMedicines = storage.getMedicines(userProfile.id);
    setMedicines(userMedicines);
  };

  const loadTodaySchedule = () => {
    const userMedicines = storage.getMedicines(userProfile.id);
    const today = new Date().toISOString().split('T')[0];
    const takenRecords = storage.getMedicineTakenRecords(userProfile.id, today);
    
    const schedule = userMedicines.map(medicine => {
      const times = getMedicineTimes(medicine.frequency);
      const taken = times.map(time => {
        return takenRecords.some(record => 
          record.medicineId === medicine.id && 
          record.scheduledTime === time && 
          record.taken
        );
      });
      
      return { medicine, times, taken };
    });
    
    setTodaySchedule(schedule);
  };

  const loadAdherence = () => {
    const rate = storage.getMedicineAdherence(userProfile.id, 7);
    setAdherenceRate(rate);
  };

  const getMedicineTimes = (frequency: string): string[] => {
    switch (frequency) {
      case 'daily':
        return ['08:00'];
      case 'twice':
        return ['08:00', '20:00'];
      case 'thrice':
        return ['08:00', '13:00', '20:00'];
      default:
        return ['08:00'];
    }
  };

  const getFrequencyText = (frequency: string) => {
    switch (frequency) {
      case 'daily': return 'দৈনিক';
      case 'twice': return 'দিনে ২ বার';
      case 'thrice': return 'দিনে ৩ বার';
      default: return frequency;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.dosage || !formData.frequency) {
      toast({
        title: "ত্রুটি",
        description: "অনুগ্রহ করে সব তথ্য পূরণ করুন",
        variant: "destructive"
      });
      return;
    }

    const medicine: Medicine = {
      id: Date.now().toString(),
      name: formData.name,
      dosage: formData.dosage,
      frequency: formData.frequency as 'daily' | 'twice' | 'thrice',
      times: getMedicineTimes(formData.frequency),
      userId: userProfile.id,
      createdAt: new Date().toISOString()
    };

    storage.saveMedicine(medicine);
    loadMedicines();
    loadTodaySchedule();
    
    setFormData({
      name: '',
      dosage: '',
      frequency: 'daily'
    });

    toast({
      title: "সফল!",
      description: "✅ ওষুধ সংরক্ষিত হয়েছে!",
    });
  };

  const handleMedicineTaken = (medicineId: string, time: string, taken: boolean) => {
    const record: MedicineTaken = {
      id: Date.now().toString(),
      medicineId,
      timestamp: new Date().toISOString(),
      scheduledTime: time,
      taken,
      userId: userProfile.id
    };

    storage.markMedicineTaken(record);
    loadTodaySchedule();
    loadAdherence();

    toast({
      title: taken ? "চমৎকার!" : "বাতিল করা হয়েছে",
      description: taken ? "ওষুধ নেওয়া হয়েছে বলে চিহ্নিত করা হয়েছে" : "ওষুধ নেওয়ার চিহ্ন সরানো হয়েছে",
    });
  };

  const handleDeleteMedicine = (id: string) => {
    storage.deleteMedicine(id);
    loadMedicines();
    loadTodaySchedule();
    toast({
      title: "মুছে ফেলা হয়েছে",
      description: "ওষুধ সফলভাবে মুছে ফেলা হয়েছে",
    });
  };

  const getScheduleStatus = (schedule: typeof todaySchedule[0], timeIndex: number) => {
    const currentTime = new Date();
    const scheduleTime = new Date();
    const [hours, minutes] = schedule.times[timeIndex].split(':');
    scheduleTime.setHours(parseInt(hours), parseInt(minutes), 0, 0);
    
    if (schedule.taken[timeIndex]) {
      return { text: 'সম্পন্ন', class: 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' };
    } else if (currentTime > scheduleTime) {
      return { text: 'মিসড', class: 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400' };
    } else {
      return { text: 'অপেক্ষমাণ', class: 'bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Add Medicine Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <PlusCircle className="mr-2 text-primary" />
            নতুন ওষুধ যোগ করুন
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name" className="bengali-font">ওষুধের নাম</Label>
              <Input
                id="name"
                type="text"
                placeholder="মেটফরমিন"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="dosage" className="bengali-font">ডোজ</Label>
              <Input
                id="dosage"
                type="text"
                placeholder="৫০০mg"
                value={formData.dosage}
                onChange={(e) => setFormData(prev => ({ ...prev, dosage: e.target.value }))}
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="frequency" className="bengali-font">ফ্রিকোয়েন্সি</Label>
              <Select value={formData.frequency} onValueChange={(value) => setFormData(prev => ({ ...prev, frequency: value }))}>
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">দৈনিক</SelectItem>
                  <SelectItem value="twice">দিনে ২ বার</SelectItem>
                  <SelectItem value="thrice">দিনে ৩ বার</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 bengali-font">
                <Save className="mr-2" size={16} />
                সংরক্ষণ করুন
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Today's Schedule */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <CalendarDays className="mr-2 text-primary" />
            আজকের সূচি
          </CardTitle>
        </CardHeader>
        <CardContent>
          {todaySchedule.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400 bengali-font">
                কোনো ওষুধ নিবন্ধিত নেই। উপরের ফর্ম ব্যবহার করে ওষুধ যোগ করুন।
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {todaySchedule.map((schedule) => (
                <div key={schedule.medicine.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h4 className="font-medium text-gray-800 dark:text-white">
                        {schedule.medicine.name} {schedule.medicine.dosage}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                        {getFrequencyText(schedule.medicine.frequency)}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteMedicine(schedule.medicine.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    {schedule.times.map((time, index) => {
                      const status = getScheduleStatus(schedule, index);
                      return (
                        <div key={time} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700 rounded">
                          <div className="flex items-center space-x-3">
                            <Checkbox
                              checked={schedule.taken[index]}
                              onCheckedChange={(checked) => 
                                handleMedicineTaken(schedule.medicine.id, time, checked as boolean)
                              }
                            />
                            <div className="flex items-center space-x-2">
                              <Clock size={16} className="text-gray-500" />
                              <span className="text-sm font-medium">{time}</span>
                            </div>
                          </div>
                          <span className={`text-xs px-2 py-1 rounded-full ${status.class}`}>
                            {status.text}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Adherence Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <PieChart className="mr-2 text-primary" />
            সাপ্তাহিক অনুসরণ
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-green-100 dark:bg-green-900/20 text-green-600 text-2xl font-bold mb-4">
              {adherenceRate}%
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
              এই সপ্তাহে আপনি {adherenceRate}% ওষুধ সময়মতো খেয়েছেন
            </p>
            {adherenceRate >= 80 && (
              <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="flex items-center justify-center space-x-2">
                  <CheckCircle className="text-green-600" size={20} />
                  <span className="text-green-800 dark:text-green-400 font-medium bengali-font">
                    চমৎকার! আপনার অনুসরণ খুবই ভালো
                  </span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Medicine List */}
      {medicines.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="bengali-font">সব ওষুধ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {medicines.map((medicine) => (
                <div key={medicine.id} className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-800 dark:text-white">
                      {medicine.name} - {medicine.dosage}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">
                      {getFrequencyText(medicine.frequency)}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteMedicine(medicine.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 size={16} />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
