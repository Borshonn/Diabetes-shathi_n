import { useState, useEffect } from 'react';
import { UserProfile } from '../types/diabetes';
import { storage } from '../lib/storage';
import { PDFGenerator } from '../lib/pdfGenerator';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { FileText, Download, BarChart3, Trophy, TrendingUp, Activity } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

interface ReportsTabProps {
  userProfile: UserProfile;
}

export default function ReportsTab({ userProfile }: ReportsTabProps) {
  const { toast } = useToast();
  const [reportConfig, setReportConfig] = useState({
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    includeGlucose: true,
    includeMedicine: true,
    includeFood: true
  });
  
  const [stats, setStats] = useState({
    averageGlucose: 0,
    medicineAdherence: 0,
    normalReadings: 0,
    highReadings: 0,
    totalReadings: 0,
    totalFoodEntries: 0
  });

  useEffect(() => {
    loadStats();
  }, [userProfile.id]);

  const loadStats = () => {
    const glucoseStats = storage.getGlucoseStats(userProfile.id, 30);
    const adherence = storage.getMedicineAdherence(userProfile.id, 30);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const foodEntries = storage.getFoodEntries(userProfile.id).filter(
      entry => new Date(entry.timestamp) >= thirtyDaysAgo
    );

    setStats({
      averageGlucose: glucoseStats.average,
      medicineAdherence: adherence,
      normalReadings: Math.round((glucoseStats.normalCount / glucoseStats.totalCount) * 100) || 0,
      highReadings: Math.round((glucoseStats.highCount / glucoseStats.totalCount) * 100) || 0,
      totalReadings: glucoseStats.totalCount,
      totalFoodEntries: foodEntries.length
    });
  };

  const handleGenerateReport = async () => {
    try {
      const startDate = new Date(reportConfig.startDate);
      const endDate = new Date(reportConfig.endDate);
      
      if (startDate > endDate) {
        toast({
          title: "ত্রুটি",
          description: "শুরুর তারিখ শেষের তারিখের পরে হতে পারে না",
          variant: "destructive"
        });
        return;
      }

      const glucoseReadings = reportConfig.includeGlucose ? 
        storage.getGlucoseReadings(userProfile.id).filter(reading => {
          const readingDate = new Date(reading.timestamp);
          return readingDate >= startDate && readingDate <= endDate;
        }) : [];

      const medicines = reportConfig.includeMedicine ? 
        storage.getMedicines(userProfile.id) : [];

      const foodEntries = reportConfig.includeFood ? 
        storage.getFoodEntries(userProfile.id).filter(entry => {
          const entryDate = new Date(entry.timestamp);
          return entryDate >= startDate && entryDate <= endDate;
        }) : [];

      const pdfGenerator = new PDFGenerator();
      pdfGenerator.generateReport({
        profile: userProfile,
        glucoseReadings,
        medicines,
        foodEntries,
        startDate: reportConfig.startDate,
        endDate: reportConfig.endDate
      });

      toast({
        title: "সফল!",
        description: "রিপোর্ট সফলভাবে ডাউনলোড হয়েছে",
      });
    } catch (error) {
      console.error('Error generating report:', error);
      toast({
        title: "ত্রুটি",
        description: "রিপোর্ট তৈরি করতে সমস্যা হয়েছে",
        variant: "destructive"
      });
    }
  };

  const achievements = [
    {
      icon: Activity,
      title: 'নিয়মিত গ্লুকোজ মনিটরিং',
      description: `গত মাসে ${stats.totalReadings}টি রিডিং`,
      achieved: stats.totalReadings >= 10,
      color: 'text-blue-600'
    },
    {
      icon: Trophy,
      title: 'ওষুধ নিয়মানুবর্তিতা',
      description: `${stats.medicineAdherence}% অনুসরণ হার`,
      achieved: stats.medicineAdherence >= 80,
      color: 'text-green-600'
    },
    {
      icon: TrendingUp,
      title: 'গ্লুকোজ নিয়ন্ত্রণ',
      description: `${stats.normalReadings}% স্বাভাবিক রিডিং`,
      achieved: stats.normalReadings >= 70,
      color: 'text-purple-600'
    },
    {
      icon: FileText,
      title: 'খাবার ট্র্যাকিং',
      description: `${stats.totalFoodEntries}টি খাবার এন্ট্রি`,
      achieved: stats.totalFoodEntries >= 20,
      color: 'text-orange-600'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Report Generation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center bengali-font">
            <FileText className="mr-2 text-red-600" />
            PDF রিপোর্ট তৈরি করুন
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate" className="bengali-font">শুরুর তারিখ</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={reportConfig.startDate}
                  onChange={(e) => setReportConfig(prev => ({ ...prev, startDate: e.target.value }))}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="endDate" className="bengali-font">শেষ তারিখ</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={reportConfig.endDate}
                  onChange={(e) => setReportConfig(prev => ({ ...prev, endDate: e.target.value }))}
                  className="mt-2"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeGlucose"
                  checked={reportConfig.includeGlucose}
                  onCheckedChange={(checked) => 
                    setReportConfig(prev => ({ ...prev, includeGlucose: checked as boolean }))
                  }
                />
                <Label htmlFor="includeGlucose" className="text-sm bengali-font">গ্লুকোজ ডেটা</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeMedicine"
                  checked={reportConfig.includeMedicine}
                  onCheckedChange={(checked) => 
                    setReportConfig(prev => ({ ...prev, includeMedicine: checked as boolean }))
                  }
                />
                <Label htmlFor="includeMedicine" className="text-sm bengali-font">ওষুধের তথ্য</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeFood"
                  checked={reportConfig.includeFood}
                  onCheckedChange={(checked) => 
                    setReportConfig(prev => ({ ...prev, includeFood: checked as boolean }))
                  }
                />
                <Label htmlFor="includeFood" className="text-sm bengali-font">খাবারের লগ</Label>
              </div>
            </div>
            
            <Button 
              onClick={handleGenerateReport}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-3 bengali-font"
            >
              <Download className="mr-2" size={20} />
              PDF ডাউনলোড করুন
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Health Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center bengali-font">
              <BarChart3 className="mr-2 text-primary" />
              সাম্প্রতিক পরিসংখ্যান
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600 dark:text-gray-400 bengali-font">গড় গ্লুকোজ</span>
                <span className="font-semibold text-gray-800 dark:text-white">
                  {stats.averageGlucose > 0 ? `${stats.averageGlucose} mmol/L` : 'N/A'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600 dark:text-gray-400 bengali-font">ওষুধ অনুসরণ</span>
                <span className={`font-semibold ${stats.medicineAdherence >= 80 ? 'text-green-600' : 'text-amber-600'}`}>
                  {stats.medicineAdherence}%
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600 dark:text-gray-400 bengali-font">স্বাভাবিক রিডিং</span>
                <span className={`font-semibold ${stats.normalReadings >= 70 ? 'text-green-600' : 'text-amber-600'}`}>
                  {stats.normalReadings}%
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600 dark:text-gray-400 bengali-font">উচ্চ রিডিং</span>
                <span className={`font-semibold ${stats.highReadings <= 30 ? 'text-green-600' : 'text-red-600'}`}>
                  {stats.highReadings}%
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600 dark:text-gray-400 bengali-font">মোট খাবার এন্ট্রি</span>
                <span className="font-semibold text-gray-800 dark:text-white">{stats.totalFoodEntries}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center bengali-font">
              <Trophy className="mr-2 text-amber-500" />
              এই মাসের অর্জন
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {achievements.map((achievement, index) => {
                const Icon = achievement.icon;
                return (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      achievement.achieved ? 'bg-green-100 dark:bg-green-900/20' : 'bg-gray-100 dark:bg-gray-700'
                    }`}>
                      <Icon className={`text-sm ${
                        achievement.achieved ? 'text-green-600' : 'text-gray-400'
                      }`} size={16} />
                    </div>
                    <div className="flex-1">
                      <p className={`text-sm font-medium ${
                        achievement.achieved ? 'text-gray-800 dark:text-white' : 'text-gray-500'
                      } bengali-font`}>
                        {achievement.title}
                      </p>
                      <p className="text-xs text-gray-500 bengali-font">
                        {achievement.description}
                      </p>
                    </div>
                    {achievement.achieved && (
                      <div className="text-green-600">
                        <Trophy size={16} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="bengali-font">সাপ্তাহিক সারসংক্ষেপ</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'গ্লুকোজ রিডিং', value: stats.totalReadings, icon: Activity, color: 'bg-blue-100 text-blue-600 dark:bg-blue-900/20' },
              { label: 'স্বাভাবিক রিডিং', value: `${stats.normalReadings}%`, icon: TrendingUp, color: 'bg-green-100 text-green-600 dark:bg-green-900/20' },
              { label: 'ওষুধ অনুসরণ', value: `${stats.medicineAdherence}%`, icon: Trophy, color: 'bg-purple-100 text-purple-600 dark:bg-purple-900/20' },
              { label: 'খাবার এন্ট্রি', value: stats.totalFoodEntries, icon: FileText, color: 'bg-orange-100 text-orange-600 dark:bg-orange-900/20' }
            ].map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2 ${stat.color}`}>
                    <Icon size={24} />
                  </div>
                  <p className="text-2xl font-bold text-gray-800 dark:text-white">{stat.value}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 bengali-font">{stat.label}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
