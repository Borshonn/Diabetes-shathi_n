export interface UserProfile {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  diabetesType: 'type1' | 'type2' | 'unknown';
  weight: number;
  height: number;
  phone?: string;
  bmi: number;
  createdAt: string;
}

export interface GlucoseReading {
  id: string;
  level: number;
  type: 'fasting' | 'post-meal' | 'random';
  time: string;
  timestamp: string;
  userId: string;
}

export interface Medicine {
  id: string;
  name: string;
  dosage: string;
  frequency: 'daily' | 'twice' | 'thrice';
  times: string[];
  userId: string;
  createdAt: string;
}

export interface MedicineTaken {
  id: string;
  medicineId: string;
  timestamp: string;
  scheduledTime: string;
  taken: boolean;
  userId: string;
}

export interface FoodEntry {
  id: string;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snacks';
  foods: string[];
  timestamp: string;
  userId: string;
}

export interface AppState {
  currentView: 'loading' | 'onboarding' | 'dashboard';
  currentTab: 'dashboard' | 'glucose' | 'medicine' | 'food' | 'reports' | 'profile' | 'settings';
  darkMode: boolean;
  userProfile: UserProfile | null;
}

export const BANGLADESH_FOODS = {
  breakfast: [
    'ভাত', 'রুটি', 'পরোটা', 'খিচুড়ি', 'পাউরুটি', 'নান', 'লুচি',
    'ডিম', 'ওমলেট', 'সেদ্ধ ডিম', 'ডিম ভাজি',
    'চা', 'কফি', 'দুধ', 'লেবু চা', 'আদা চা',
    'কলা', 'আপেল', 'পেঁপে', 'আম', 'আনারস',
    'দই', 'মিষ্টি দই', 'চিড়া', 'মুড়ি', 'সুজি'
  ],
  lunch: [
    'ভাত', 'বাসমতি চাল', 'লাল চাল', 'পোলাও', 'বিরিয়ানি',
    'মাছ', 'রুই মাছ', 'কাতলা মাছ', 'ইলিশ মাছ', 'চিংড়ি মাছ',
    'মাংস', 'গরুর মাংস', 'খাসির মাংস', 'মুরগির মাংস',
    'ডাল', 'মসুর ডাল', 'মুগ ডাল', 'ছোলার ডাল', 'অড়হর ডাল',
    'সবজি', 'আলু', 'বেগুন', 'লাউ', 'মুলা', 'গাজর', 'শিম', 'বাঁধাকপি',
    'ভর্তা', 'বেগুন ভর্তা', 'আলু ভর্তা', 'শুটকি ভর্তা',
    'তরকারি', 'মিশ্র সবজি', 'আলু সবজি'
  ],
  dinner: [
    'ভাত', 'রুটি', 'খিচুড়ি', 'নুডলস', 'পাস্তা',
    'মাছ', 'ছোট মাছ', 'শুটকি মাছ',
    'সবজি', 'সবুজ সবজি', 'সালাদ', 'কাঁচা সবজি',
    'ডাল', 'হালকা ডাল', 'সবুজ ডাল',
    'স্যুপ', 'সবজি স্যুপ', 'চিকেন স্যুপ'
  ],
  snacks: [
    'চা', 'কফি', 'গ্রিন টি', 'লেমন টি', 'মসলা চা',
    'বিস্কুট', 'ক্র্যাকার', 'রাস্ক', 'টোস্ট',
    'ফল', 'কলা', 'আপেল', 'কমলা', 'পেয়ারা', 'আঙুর',
    'মুড়ি', 'চানাচুর', 'বাদাম', 'কাজুবাদাম', 'চিনাবাদাম',
    'পিঠা', 'চিতই পিঠা', 'ভাপা পিঠা', 'পুলি পিঠা',
    'সিঙ্গারা', 'সমুচা', 'পিয়াজু', 'বেগুনি', 'চপ',
    'দই', 'লাস্সি', 'বোরহানি', 'ফালুদা',
    'মিষ্টি', 'রসগোল্লা', 'সন্দেশ', 'গুলাব জামুন'
  ]
};
