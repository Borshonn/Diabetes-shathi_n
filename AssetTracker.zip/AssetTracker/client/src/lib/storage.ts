import { UserProfile, GlucoseReading, Medicine, MedicineTaken, FoodEntry } from '../types/diabetes';

export class DiabetesStorage {
  private getItem<T>(key: string): T[] {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : [];
    } catch {
      return [];
    }
  }

  private setItem<T>(key: string, data: T[]): void {
    localStorage.setItem(key, JSON.stringify(data));
  }

  // User Profile
  saveUserProfile(profile: UserProfile): void {
    localStorage.setItem('userProfile', JSON.stringify(profile));
  }

  getUserProfile(): UserProfile | null {
    try {
      const profile = localStorage.getItem('userProfile');
      return profile ? JSON.parse(profile) : null;
    } catch {
      return null;
    }
  }

  // Glucose Readings
  saveGlucoseReading(reading: GlucoseReading): void {
    const readings = this.getItem<GlucoseReading>('glucoseReadings');
    readings.push(reading);
    this.setItem('glucoseReadings', readings);
  }

  getGlucoseReadings(userId: string): GlucoseReading[] {
    return this.getItem<GlucoseReading>('glucoseReadings')
      .filter(reading => reading.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  updateGlucoseReading(id: string, updates: Partial<GlucoseReading>): void {
    const readings = this.getItem<GlucoseReading>('glucoseReadings');
    const index = readings.findIndex(r => r.id === id);
    if (index !== -1) {
      readings[index] = { ...readings[index], ...updates };
      this.setItem('glucoseReadings', readings);
    }
  }

  deleteGlucoseReading(id: string): void {
    const readings = this.getItem<GlucoseReading>('glucoseReadings');
    const filtered = readings.filter(r => r.id !== id);
    this.setItem('glucoseReadings', filtered);
  }

  // Medicines
  saveMedicine(medicine: Medicine): void {
    const medicines = this.getItem<Medicine>('medicines');
    medicines.push(medicine);
    this.setItem('medicines', medicines);
  }

  getMedicines(userId: string): Medicine[] {
    return this.getItem<Medicine>('medicines')
      .filter(medicine => medicine.userId === userId);
  }

  deleteMedicine(id: string): void {
    const medicines = this.getItem<Medicine>('medicines');
    const filtered = medicines.filter(m => m.id !== id);
    this.setItem('medicines', filtered);
  }

  // Medicine Taken Records
  markMedicineTaken(record: MedicineTaken): void {
    const records = this.getItem<MedicineTaken>('medicineTaken');
    records.push(record);
    this.setItem('medicineTaken', records);
  }

  getMedicineTakenRecords(userId: string, date?: string): MedicineTaken[] {
    let records = this.getItem<MedicineTaken>('medicineTaken')
      .filter(record => record.userId === userId);
    
    if (date) {
      records = records.filter(record => 
        record.timestamp.startsWith(date)
      );
    }
    
    return records;
  }

  // Food Entries
  saveFoodEntry(entry: FoodEntry): void {
    const entries = this.getItem<FoodEntry>('foodEntries');
    entries.push(entry);
    this.setItem('foodEntries', entries);
  }

  getFoodEntries(userId: string, date?: string): FoodEntry[] {
    let entries = this.getItem<FoodEntry>('foodEntries')
      .filter(entry => entry.userId === userId);
    
    if (date) {
      entries = entries.filter(entry => 
        entry.timestamp.startsWith(date)
      );
    }
    
    return entries.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  // Statistics
  getGlucoseStats(userId: string, days: number = 30): {
    average: number;
    normalCount: number;
    highCount: number;
    totalCount: number;
  } {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    const readings = this.getGlucoseReadings(userId)
      .filter(reading => new Date(reading.timestamp) >= cutoffDate);
    
    const totalCount = readings.length;
    const average = totalCount > 0 ? 
      readings.reduce((sum, r) => sum + r.level, 0) / totalCount : 0;
    
    let normalCount = 0;
    let highCount = 0;
    
    readings.forEach(reading => {
      if (reading.level <= 10) normalCount++;
      else highCount++;
    });
    
    return {
      average: Math.round(average * 10) / 10,
      normalCount,
      highCount,
      totalCount
    };
  }

  getMedicineAdherence(userId: string, days: number = 7): number {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    const medicines = this.getMedicines(userId);
    const takenRecords = this.getMedicineTakenRecords(userId)
      .filter(record => new Date(record.timestamp) >= cutoffDate);
    
    if (medicines.length === 0) return 0;
    
    const totalExpected = medicines.reduce((sum, med) => {
      const frequency = med.frequency === 'daily' ? 1 : 
                      med.frequency === 'twice' ? 2 : 3;
      return sum + (frequency * days);
    }, 0);
    
    const totalTaken = takenRecords.filter(record => record.taken).length;
    
    return Math.round((totalTaken / totalExpected) * 100);
  }
}

export const storage = new DiabetesStorage();
