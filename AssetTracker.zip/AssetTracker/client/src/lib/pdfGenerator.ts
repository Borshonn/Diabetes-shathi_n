import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { UserProfile, GlucoseReading, Medicine, FoodEntry } from '../types/diabetes';
import { storage } from './storage';

interface ReportData {
  profile: UserProfile;
  glucoseReadings: GlucoseReading[];
  medicines: Medicine[];
  foodEntries: FoodEntry[];
  startDate: string;
  endDate: string;
}

export class PDFGenerator {
  private doc: jsPDF;

  constructor() {
    this.doc = new jsPDF();
  }

  generateReport(data: ReportData): void {
    const { profile, glucoseReadings, medicines, foodEntries, startDate, endDate } = data;

    // Header
    this.addHeader(profile, startDate, endDate);
    
    // Patient Info
    this.addPatientInfo(profile);
    
    // Glucose Summary
    this.addGlucoseSummary(glucoseReadings);
    
    // Glucose Readings Table
    this.addGlucoseTable(glucoseReadings);
    
    // Medicine Information
    this.addMedicineInfo(medicines);
    
    // Food Log Summary
    this.addFoodSummary(foodEntries);
    
    // Footer
    this.addFooter();
    
    // Download
    const fileName = `Diabetes_Report_${profile.name}_${new Date().toISOString().split('T')[0]}.pdf`;
    this.doc.save(fileName);
  }

  private addHeader(profile: UserProfile, startDate: string, endDate: string): void {
    this.doc.setFontSize(20);
    this.doc.setTextColor(20, 184, 166); // Primary color
    this.doc.text('ডায়াবেটিস সাথী', 20, 20);
    
    this.doc.setFontSize(12);
    this.doc.setTextColor(0, 0, 0);
    this.doc.text('GlucoShathi KUET Team', 20, 30);
    
    this.doc.setFontSize(16);
    this.doc.text('রোগীর স্বাস্থ্য রিপোর্ট', 20, 45);
    
    this.doc.setFontSize(10);
    this.doc.text(`রিপোর্টের সময়কাল: ${startDate} থেকে ${endDate}`, 20, 55);
    this.doc.text(`তৈরির তারিখ: ${new Date().toLocaleDateString('bn-BD')}`, 20, 65);
    
    this.doc.line(20, 70, 190, 70);
  }

  private addPatientInfo(profile: UserProfile): void {
    let y = 80;
    
    this.doc.setFontSize(14);
    this.doc.setTextColor(0, 0, 0);
    this.doc.text('রোগীর তথ্য', 20, y);
    
    y += 10;
    this.doc.setFontSize(10);
    this.doc.text(`নাম: ${profile.name}`, 20, y);
    this.doc.text(`বয়স: ${profile.age} বছর`, 100, y);
    
    y += 8;
    this.doc.text(`লিঙ্গ: ${this.getGenderText(profile.gender)}`, 20, y);
    this.doc.text(`ডায়াবেটিসের ধরন: ${this.getDiabetesTypeText(profile.diabetesType)}`, 100, y);
    
    y += 8;
    this.doc.text(`ওজন: ${profile.weight} কেজি`, 20, y);
    this.doc.text(`উচ্চতা: ${profile.height} সেমি`, 100, y);
    
    y += 8;
    this.doc.text(`BMI: ${profile.bmi}`, 20, y);
    if (profile.phone) {
      this.doc.text(`ফোন: ${profile.phone}`, 100, y);
    }
    
    this.doc.line(20, y + 10, 190, y + 10);
  }

  private addGlucoseSummary(readings: GlucoseReading[]): void {
    let y = 150;
    
    this.doc.setFontSize(14);
    this.doc.text('গ্লুকোজ সারসংক্ষেপ', 20, y);
    
    if (readings.length === 0) {
      y += 10;
      this.doc.setFontSize(10);
      this.doc.text('এই সময়কালে কোনো গ্লুকোজ রিডিং নেই', 20, y);
      return;
    }
    
    const average = readings.reduce((sum, r) => sum + r.level, 0) / readings.length;
    const normalCount = readings.filter(r => r.level <= 10).length;
    const highCount = readings.filter(r => r.level > 10).length;
    
    y += 10;
    this.doc.setFontSize(10);
    this.doc.text(`মোট রিডিং: ${readings.length}`, 20, y);
    this.doc.text(`গড় গ্লুকোজ: ${average.toFixed(1)} mmol/L`, 100, y);
    
    y += 8;
    this.doc.text(`স্বাভাবিক রিডিং: ${normalCount} (${Math.round(normalCount/readings.length*100)}%)`, 20, y);
    this.doc.text(`উচ্চ রিডিং: ${highCount} (${Math.round(highCount/readings.length*100)}%)`, 100, y);
    
    this.doc.line(20, y + 10, 190, y + 10);
  }

  private addGlucoseTable(readings: GlucoseReading[]): void {
    if (readings.length === 0) return;
    
    const tableData = readings.slice(0, 30).map(reading => [
      new Date(reading.timestamp).toLocaleDateString('bn-BD'),
      reading.time,
      `${reading.level} mmol/L`,
      this.getReadingTypeText(reading.type),
      this.getGlucoseStatus(reading.level),
      this.getRecommendation(reading.level)
    ]);

    (this.doc as any).autoTable({
      head: [['তারিখ', 'সময়', 'মাত্রা', 'ধরন', 'অবস্থা', 'পরামর্শ']],
      body: tableData,
      startY: 190,
      styles: { fontSize: 7, cellPadding: 2 },
      headStyles: { fillColor: [20, 184, 166], fontSize: 8 },
      columnStyles: {
        5: { cellWidth: 40 }
      }
    });
  }

  private addMedicineInfo(medicines: Medicine[]): void {
    const finalY = (this.doc as any).lastAutoTable?.finalY || 200;
    let y = finalY + 20;
    
    this.doc.setFontSize(14);
    this.doc.text('ওষুধের তথ্য ও সেবনের বিবরণ', 20, y);
    
    if (medicines.length === 0) {
      y += 10;
      this.doc.setFontSize(10);
      this.doc.text('কোনো ওষুধ নিবন্ধিত নেই', 20, y);
      return;
    }
    
    const medicineData = medicines.map(medicine => [
      medicine.name,
      medicine.dosage,
      this.getFrequencyText(medicine.frequency),
      medicine.times.join(', '),
      new Date(medicine.createdAt).toLocaleDateString('bn-BD'),
      this.getMedicineInstructions(medicine.name)
    ]);

    (this.doc as any).autoTable({
      head: [['ওষুধের নাম', 'ডোজ', 'ফ্রিকোয়েন্সি', 'সময়', 'শুরুর তারিখ', 'নির্দেশনা']],
      body: medicineData,
      startY: y + 10,
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [34, 197, 94], fontSize: 9 },
      columnStyles: {
        5: { cellWidth: 35 }
      }
    });
  }

  private addFoodSummary(foodEntries: FoodEntry[]): void {
    const finalY = (this.doc as any).lastAutoTable?.finalY || 200;
    let y = finalY + 20;
    
    // Add new page if needed
    if (y > 250) {
      this.doc.addPage();
      y = 20;
    }
    
    this.doc.setFontSize(14);
    this.doc.text('খাবারের বিস্তারিত তথ্য', 20, y);
    
    if (foodEntries.length === 0) {
      this.doc.setFontSize(10);
      this.doc.text('এই সময়কালে কোনো খাবারের তথ্য নেই', 20, y + 10);
      return;
    }
    
    const foodData = foodEntries.slice(0, 50).map(entry => [
      new Date(entry.timestamp).toLocaleDateString('bn-BD'),
      new Date(entry.timestamp).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
      this.getMealTypeText(entry.mealType),
      entry.foods.join(', '),
      this.getFoodNutritionAdvice(entry.mealType, entry.foods.length)
    ]);

    (this.doc as any).autoTable({
      head: [['তারিখ', 'সময়', 'খাবারের ধরন', 'খাবারের তালিকা', 'পুষ্টি পরামর্শ']],
      body: foodData,
      startY: y + 10,
      styles: { fontSize: 7, cellPadding: 2 },
      headStyles: { fillColor: [251, 146, 60], fontSize: 8 },
      columnStyles: {
        3: { cellWidth: 50 },
        4: { cellWidth: 40 }
      }
    });
  }

  private addFooter(): void {
    const pageHeight = this.doc.internal.pageSize.height;
    this.doc.setFontSize(8);
    this.doc.setTextColor(128, 128, 128);
    this.doc.text('এই রিপোর্টটি ডায়াবেটিস সাথী অ্যাপ দ্বারা তৈরি করা হয়েছে।', 20, pageHeight - 20);
    this.doc.text('চিকিৎসা সংক্রান্ত যেকোনো সিদ্ধান্তের জন্য অবশ্যই ডাক্তারের পরামর্শ নিন।', 20, pageHeight - 15);
  }

  private getGenderText(gender: string): string {
    switch (gender) {
      case 'male': return 'পুরুষ';
      case 'female': return 'নারী';
      case 'other': return 'অন্যান্য';
      default: return gender;
    }
  }

  private getDiabetesTypeText(type: string): string {
    switch (type) {
      case 'type1': return 'টাইপ ১';
      case 'type2': return 'টাইপ ২';
      case 'unknown': return 'জানা নেই';
      default: return type;
    }
  }

  private getReadingTypeText(type: string): string {
    switch (type) {
      case 'fasting': return 'খালি পেটে';
      case 'post-meal': return 'খাবারের পর';
      case 'random': return 'যেকোনো সময়';
      default: return type;
    }
  }

  private getFrequencyText(frequency: string): string {
    switch (frequency) {
      case 'daily': return 'দৈনিক';
      case 'twice': return 'দিনে ২ বার';
      case 'thrice': return 'দিনে ৩ বার';
      default: return frequency;
    }
  }

  private getMealTypeText(mealType: string): string {
    switch (mealType) {
      case 'breakfast': return 'নাস্তা';
      case 'lunch': return 'দুপুরের খাবার';
      case 'dinner': return 'রাতের খাবার';
      case 'snacks': return 'জলখাবার';
      default: return mealType;
    }
  }

  private getGlucoseStatus(level: number): string {
    if (level <= 7) return 'স্বাভাবিক';
    if (level <= 10) return 'সীমান্তরেখা';
    return 'উচ্চ';
  }

  private getRecommendation(level: number): string {
    if (level <= 4) return 'হাইপো - জরুরি চিকিৎসা';
    if (level <= 7) return 'চমৎকার নিয়ন্ত্রণ';
    if (level <= 10) return 'সতর্ক থাকুন';
    if (level <= 15) return 'ওষুধ সমন্বয় করুন';
    return 'জরুরি ডাক্তারি সহায়তা';
  }

  private getMedicineInstructions(medicineName: string): string {
    const name = medicineName.toLowerCase();
    if (name.includes('মেটফরমিন') || name.includes('metformin')) {
      return 'খাবারের সাথে নিন';
    } else if (name.includes('ইনসুলিন') || name.includes('insulin')) {
      return 'খাবারের ১৫ মিনিট আগে';
    } else if (name.includes('গ্লিবেনক্লামাইড')) {
      return 'খাবারের আগে নিন';
    }
    return 'ডাক্তারের পরামর্শ অনুযায়ী';
  }

  private getFoodNutritionAdvice(mealType: string, itemCount: number): string {
    if (mealType === 'breakfast') {
      return itemCount > 3 ? 'প্রোটিন ও ফাইবার বাড়ান' : 'সুষম নাস্তা';
    } else if (mealType === 'lunch') {
      return itemCount > 4 ? 'পরিমাণ কমান' : 'সবজি বাড়ান';
    } else if (mealType === 'dinner') {
      return 'হালকা খাবার পছন্দনীয়';
    }
    return 'স্বাস্থ্যকর নাস্তা';
  }
}

export const pdfGenerator = new PDFGenerator();
