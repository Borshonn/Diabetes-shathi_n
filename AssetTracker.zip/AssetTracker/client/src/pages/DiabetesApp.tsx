'use client'

import { useState, useEffect } from 'react';
import { UserProfile, AppState } from '../types/diabetes';
import { storage } from '../lib/storage';
import LoadingScreen from '../components/LoadingScreen';
import OnboardingScreen from '../components/OnboardingScreen';
import DashboardScreen from '../components/DashboardScreen';

export default function DiabetesApp() {
  const [appState, setAppState] = useState<AppState>({
    currentView: 'loading',
    currentTab: 'dashboard',
    darkMode: false,
    userProfile: null
  });

  useEffect(() => {
    // Load saved theme
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const shouldUseDark = savedTheme === 'dark' || (!savedTheme && prefersDark);
    
    if (shouldUseDark) {
      document.documentElement.classList.add('dark');
      setAppState(prev => ({ ...prev, darkMode: true }));
    }

    // Check if user has completed onboarding
    setTimeout(() => {
      const profile = storage.getUserProfile();
      if (profile) {
        setAppState(prev => ({
          ...prev,
          currentView: 'dashboard',
          userProfile: profile
        }));
      } else {
        setAppState(prev => ({ ...prev, currentView: 'onboarding' }));
      }
    }, 2000);
  }, []);

  const handleOnboardingComplete = (profileData: UserProfile) => {
    storage.saveUserProfile(profileData);
    setAppState(prev => ({
      ...prev,
      currentView: 'dashboard',
      userProfile: profileData
    }));
  };

  const toggleDarkMode = () => {
    const newDarkMode = !appState.darkMode;
    document.documentElement.classList.toggle('dark', newDarkMode);
    localStorage.setItem('theme', newDarkMode ? 'dark' : 'light');
    setAppState(prev => ({ ...prev, darkMode: newDarkMode }));
  };

  const setCurrentTab = (tab: AppState['currentTab']) => {
    setAppState(prev => ({ ...prev, currentTab: tab }));
  };

  if (appState.currentView === 'loading') {
    return <LoadingScreen />;
  }

  if (appState.currentView === 'onboarding') {
    return <OnboardingScreen onComplete={handleOnboardingComplete} />;
  }

  if (appState.currentView === 'dashboard' && appState.userProfile) {
    return (
      <DashboardScreen
        userProfile={appState.userProfile}
        currentTab={appState.currentTab}
        darkMode={appState.darkMode}
        onTabChange={setCurrentTab}
        onToggleDarkMode={toggleDarkMode}
      />
    );
  }

  return <LoadingScreen />;
}
